#ifndef SUBSTRING_H
#define SUBSTRING_H

void substring(char s[], char sub[], int p, int l) {
	int c = 0;
	
	while (c < l) {
		sub[c] = s[p+c-1];
		c++;
	}
	sub[c] = '\0';
}

#endif